mapboxgl.accessToken = 'pk.eyJ1IjoiZGlzYXN0ZXJpbyIsImEiOiJjazF3eXpuaDgwNzMzM2x1YXA2YzViOGFwIn0.r_CUebFU80v4DrNZLTL1Tw';
var dataList = [];


// Word List
var wordList = ["arson", "arsonist", "avalanche", "barometer", "Beaufortscale", "blackout", "blizzard"
    , "blow", "cloud", "crust", "cumulonimbus", "cyclone", "dam", "drought", "duststorm", "earthquake", "erosion"
    , "fatal", "fault", "fire", "flood", "fog", "force", "forest", "forestfire", "gale", "geyser", "gust", "hail"
    , "hailstorm", "heat", "high-pressure", "hurricane", "iceberg", "kamikaze", "lack", "lava", "lightning", "low-pressure"
    , "magma", "mountain", "nimbus", "ocean", "permafrost", "rain", "rainstorm", "Richterscale", "river", "sandstorm"
    , "sea", "seismic", "sinking", "snowstorm", "storm", "stuck", "thunderstorm", "tornado", "tsunami", "twister"
    , "violentstorm", "volcano", "volt", "whirlpool", "whirlwind", "windscale", "windvane", "windstorm", "heatwave"
    , "wave", "tremor", "underground", "death", "casualty", "fatality", "disaster", "money", "lost", "damage", "life"
    , "poor", "shelter", "rescue", "coast", "monster", "myth", "science", "scientist", "god", "goddess", "sink", "boat"
    , "destruction", "destroy", "uproot", "tree", "fate", "poverty", "impoverish", "farm", "touchdown", "zap", "tension"
    , "nightmare", "monstrosity", "oil", "spill", "cataclysm", "Bermuda", "BermudaTriangle", "wind", "windy", "wave"
    , "ice", "transport"];

var map = new mapboxgl.Map({
    container: 'map', // container id
    style: 'mapbox://styles/mapbox/streets-v11', // stylesheet location
    center: [-80.5112, 43.42537], // starting position [lng, lat]
    zoom: 4 // starting zoom
});

var geocoder = new MapboxGeocoder({
    accessToken: mapboxgl.accessToken,
    marker: {
        color: 'orange'
    },
    mapboxgl: mapboxgl
});

map.addControl(geocoder);

// Add geolocate control to the map.
map.addControl(new mapboxgl.GeolocateControl({
    positionOptions: {
        enableHighAccuracy: true
    },
    trackUserLocation: true
}));


// Function to grab location
function getLocation () {
    // Get Location
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(setLocation)
    } else {
        alert("Your browser doesn't support this function sorry homie");
    }
}

function setLocation (position) {
    console.log("Long: "+position.coords.longitude);
    console.log("Lat : "+position.coords.latitude);
}

$(document).ready(function () {


    map.on('load', function () {

        $.getJSON("https://eonet.sci.gsfc.nasa.gov/api/v2.1/events", getData);

    });

    $("#icon-layers").on('click', function() {

        // Get overlay
        let overlay = $("#overlay");

        // Check Height
        if (overlay.height() > 100) {
            overlay.height(40);
            $('#icon-layers').css('border-bottom', 'none');
        } else {
            overlay.height(400);
            $('#icon-layers').css('border-bottom', '1px black solid');
        }


    });


    function getCoords (object) {
        // tempory holder
        let holder;

        // Zoom that bitch in
        dataList.forEach(ele => {
            if (ele.id == object.id) {
                holder = ele;
                return;
            }
        });

        return holder;
    }

    function getData(data) {

        // Get each event into array
        let arr = data.events;
        dataList = arr;

        // Parse each object into coordinated and click elements
        arr.forEach(ele => {

            //Get properties
            let id = ele.id;
            let title = ele.title;
            let description = ele.description;
            let link = ele.link;
            let imageName = getImageFromTitle(ele.categories[0].title);

            console.log(ele.id);
            // create a HTML element for each feature
            var el = document.createElement('div');
            el.className = 'marker';
            el.id = id;

            var er = document.createElement('img');
            er.className = 'marker-img';
            er.src = imageName;
            er.width = "40px;";
            er.height = "40px;";

            el.appendChild(er);

            $(el).on('click', function() {

                console.log(getCoords(ele).geometries[0].coordinates.reverse());
                map.flyTo({
                    center: getCoords(ele).geometries[0].coordinates.reverse(),
                    zoom: 12,
                    speed: 1,
                });
            });

            // make a marker for each feature and add to the map
            if (ele.geometries[0].type == "Point") {
                new mapboxgl.Marker(el)
                    .setLngLat(ele.geometries[0].coordinates)
                    .addTo(map);

            }
        });
    }

        function getImageFromTitle(title) {
            // Image names
            let images = ["dust-and-haze", "icebergs", "manmade", "sea-and-lake-ice", "severe-storms", "snow", "volcanoes", "water-color", "wildfires"]
            let temp = "";

            images.forEach(ele => {
                title = title.split(" ").join("-").toLowerCase();
                if (title == ele) {
                    temp = "/Nasa/Res/icon-" + ele + ".svg";
                }
            });

            return temp;
        }


        $('#upload-report').on('click', function () {

            // Click input
            $(".file-upload").click();

        });

    function readURL(input) {
        // Click to upload a image
        let apiKey = "AIzaSyBuibd6uAiLx1pvKlHdZrZUQsSqD0zsyU8";
        let rq = "";

        if (input.files && input.files[0]) {

            var FR= new FileReader();

            FR.addEventListener("load", function(e) {
                imageString = e.target.result;
                imageString = imageString.split(",")[1];
                rq = '{\n' +
                    '  "requests":[\n' +
                    '    {\n' +
                    '      "image":{\n' +
                    '        "content":\n' +
                    '        "'+imageString+'"\n' +
                    '      },\n' +
                    '      "features":[\n' +
                    '        {\n' +
                    '          "type":"LABEL_DETECTION",\n' +
                    '          "maxResults":5\n' +
                    '        }\n' +
                    '      ]\n' +
                    '    }\n' +
                    '  ]\n' +
                    '}';
                console.log(rq);
                // Make Request
                $.ajax({
                    type: "POST",
                    url: "https://vision.googleapis.com/v1/images:annotate?key="+apiKey,
                    data: rq,
                    success: checkLabels,
                    dataType: "json",
                    contentType: "application/json; charset=utf-8"
                });
            });

            FR.readAsDataURL( input.files[0] );


        }

    }


    function isValidDisaster (value) {

        let flag = false;

        wordList.forEach(word => {

            if (word == value.toLowerCase()) {
                flag = true;
            }

        });

        return flag;
    }

    function checkLabels(data) {

        // Output
        let wordOne = data.responses[0].labelAnnotations[0].description;
        let wordTwo = data.responses[0].labelAnnotations[1].description;
        let wordThree = data.responses[0].labelAnnotations[2].description;
        console.log(wordOne+" "+wordTwo+" "+wordThree);
        let flag = false;

        // Check words
        if (isValidDisaster(wordOne) || isValidDisaster(wordTwo) || isValidDisaster(wordThree)) {
            // Chamge camera Icon
            flag = true;
            $(".camera-icon").attr("src", "./Res/check-mark.png");

        } else {
            // Chamge camera Icon
            flag = false;
            $(".camera-icon").attr("src", "./Res/red-x.png");


        }

    }


    $(".file-upload").on('change', function(){
        readURL(this);
    });


    $("#report-btn").click(()=> {
        $("#modal-select").removeAttr("hidden");
    });

    $("#report1-submit").click(() => {
        let text = highlighted.children("p").text();
        $("#modal-reportfor").text(`Report for ${text}`);
        $("#modal-select").attr("hidden", true);
        $("#modal-report").removeAttr("hidden");
    });

    $("#report1-close").click(() => {
        $("#modal-select").attr("hidden", true);
    });

    $("#report-submit").click(()=> {
        $("#modal-report").attr("hidden", true);
    });

    $("#report-close").click(()=> {
        $("#modal-report").attr("hidden", true);
    });


    var highlighted;

    $(".highlight-on-click").click(function() {

        // remove highlight on click class
        // add highlight on click class to current
        // store reference to currently highlighted

        if (highlighted != undefined) {
            highlighted.toggleClass("highlight");
        }

        $(this).toggleClass("highlight");
        highlighted = $(this);
    });


});
